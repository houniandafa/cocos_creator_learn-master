
export  enum CellState {
    black,
    white,
}