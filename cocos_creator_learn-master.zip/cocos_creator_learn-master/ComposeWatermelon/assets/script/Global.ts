export const Global_Date = {
	fruitType: 0,
	Score: 0,
	cheat: false,
};

export const WATERMELON_ARRAY: cc.Node[] = [];
