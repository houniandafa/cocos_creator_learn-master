export enum RunState{
    run='pande_run',                    //跑步
    jump='pande_jump',                  //跳跃
    double_jump='pande_roll'            //二段跳 滚动动画
}