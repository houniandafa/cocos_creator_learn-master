export const Data={
    score:0,
    speed:0
}