## cocos creator 小游戏

参考了各类的小游戏源码和demo,素材来源于网络和一些视频教程

大部分都是学习时做的,可能注释做的不太好,代码会慢慢整理的

主要用于学习,使用的代码量都不大,很适合新人学习.

> 代码供学习使用,请勿用于商业用途

引擎版本 2.4.8

### 游戏列表

像素鸟

| 游戏项目         | 效果图                                                       |
| ---------------- | ------------------------------------------------------------ |
| 合成大西瓜       | <img src="Readme/合成大西瓜.png" alt="合成大西瓜" style="zoom:50%;" /> |
| Flappy Bird      | <img src="Readme/像素鸟.png" alt="image-20220404230421301 " style="zoom:50%;" /> |
| 见缝插针         | ![image-20220405103808098](Readme/image-20220405103808098.png) |
| 飞机大战         | <img src="Readme/飞机大战.png" alt="飞机大战" style="zoom:50%;" /> |
| 熊猫跑酷         | <img src="Readme/image-20220405180136888.png" alt="image-20220405180136888" style="zoom:50%;" /> |
| 拼图游戏         | <img src="Readme/image-20220405185912735.png" alt="image-20220405185912735" style="zoom:50%;" /> |
| 水果忍者         | <img src="Readme/image-20220406012543698.png" alt="image-20220406012543698" style="zoom:50%;" /> |
| 跳一跳           | <img src="Readme/image-20220406012837418.png" alt="image-20220406012837418" style="zoom:50%;" /> |
| 吃星星(官方例子) | <img src="Readme/image-20220406110404383.png" alt="image-20220406110404383" style="zoom:50%;" /> |
| 汉诺塔           | <img src="Readme/image-20220406131115857.png" alt="image-20220406131115857" style="zoom:50%;" /> |
| 打砖块           | <img src="Readme/image-20220406133149152.png" alt="image-20220406133149152" style="zoom:50%;" /> |
| 五子棋           | <img src="Readme/image-20220406133725819.png" alt="image-20220406133725819" style="zoom:50%;" /> |
| 生命游戏         | <img src="Readme/image-20220406135106843.png" alt="image-20220406135106843" style="zoom:50%;" /> |
| 2D像素小游戏     | ![image-20220519023113037](Readme/image-20220519023113037.png) |
