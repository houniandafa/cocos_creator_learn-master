
export enum ItemType {
	bomb = 0,
	fire,
}