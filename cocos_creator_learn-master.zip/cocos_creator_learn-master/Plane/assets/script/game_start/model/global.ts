export let Global = {
    score:0,
    bombSize:0
};