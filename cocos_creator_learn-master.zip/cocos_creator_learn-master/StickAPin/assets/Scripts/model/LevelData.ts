export default interface LevelData{
    level:number;               //关卡
    big:number                  //大球
    small:number                //准备发射的球
    speed:number                //旋转速度
    dir:number                  //旋转方向
}