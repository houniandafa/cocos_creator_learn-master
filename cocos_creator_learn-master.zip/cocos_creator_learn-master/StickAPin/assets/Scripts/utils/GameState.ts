
export enum GameState {
    StartGame,
    GameOver,
    NextLevel,
}